/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author Dell
 */
public class authenticator {
    
    public static Object getInputs(String username, String password)
    {
        userBean user1=userDAO.getUser(username);
       
        String un=user1.getUsername();
        String pw=user1.getPassword();
        //String rl=user1.getRole();
        
        message msg=new message();
        
        
        
        if(un==null){
           
            msg.setMessage("Username invalid");
            msg.setStatus(1);
            return msg;
        }
            
        
        else if(password.compareTo(pw)!=0){

            msg.setMessage("Password invalid");
            msg.setStatus(2);
            return msg;}
        
        else
        {

            msg.setMessage("Log in successful");
            msg.setStatus(3);
            msg.setUserB(user1);
            
            return msg;
        }
      
        
    }
    
}
