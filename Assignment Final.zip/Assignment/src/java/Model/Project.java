/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Nuzla
 */
public class Project implements java.io.Serializable{

    public Project(String ID, String title, String description, String teacher, String student, String studentsFeedback, String teachersFeedback, String startDate, String endDate) {
        this.ID = ID;
        this.title = title;
        this.description = description;
        this.teacher = teacher;
        this.student = student;
        this.studentsFeedback = studentsFeedback;
        this.teachersFeedback = teachersFeedback;
        this.startDate = startDate;
        this.endDate = endDate;
    }

  
    
    private String ID;
    private String title; 
    private String description;
     private String teacher;
    private String student;
    private String studentsFeedback;
    private String teachersFeedback;
    private String startDate;
    private String endDate;

    
   
   

    public String getStudentsFeedback() {
        return studentsFeedback;
    }

    public void setStudentsFeedback(String studentsFeedback) {
        this.studentsFeedback = studentsFeedback;
    }

    public String getTeachersFeedback() {
        return teachersFeedback;
    }

    public void setTeachersFeedback(String teachersFeedback) {
        this.teachersFeedback = teachersFeedback;
    }
    
    public void setStudent(String student) {
        this.student = student;
    }
  

    public String getStudent() {
        return student;
    }

   
    public Project(){}
    
    
    @Override
    
    
    public String toString() {
        return "Project{" + "title=" + title + ", description=" + description + ", startDate=" + startDate + ", endDate=" + endDate + ", teacher=" + teacher + '}';
    }


    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the teacher
     */
    public String getTeacher() {
        return teacher;
    }

    /**
     * @param teacher the teacher to set
     */
    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    /**
     * @return the ID
     */
    public String getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(String ID) {
        this.ID = ID;
    }
    
}
