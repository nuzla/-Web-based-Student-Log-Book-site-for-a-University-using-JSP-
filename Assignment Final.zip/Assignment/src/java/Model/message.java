/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author cb004639
 */
public class message implements java.io.Serializable{
    
     private String message;
     private int status;
     private userBean userB;
    
    public message()
    {
        
    }
    
    public message(String message,int status,userBean userB)
    {
        this.message=message;
        this.status=status;
        this.userB=userB;
    }
        
     
     
     public String getMessage()
     {
        return message;
     }
     public void setMessage(String message)
     {
        this.message=message;
     }
     
     public int getStatus()
     {
        return status;
     }
     public void setStatus(int status)
     {
        this.status=status;
     }
     public userBean getUserB()
     {
        return userB;
     }
     public void setUserB(userBean userB)
     {
        this.userB=userB;
     }
     
     
   
     public String toString()
     {
         return "bean";
     }
}

