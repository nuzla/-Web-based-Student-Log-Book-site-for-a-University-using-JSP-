/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import static java.lang.System.in;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class userDAO {
   private static String url;
   private static Connection con;
    
    /** Creates a new instance of userDAO*/
    
    static{
        try
        {
            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
            url = "jdbc:derby://localhost:1527/Assignment;create=true;user=nuzla;password=nuzla";
            con = DriverManager.getConnection(url); 
        }
        
        catch (Exception cnfe)
        {
            System.err.println("Unable to load database driver");
            System.err.println("Details : "+cnfe);
            System.exit(0);
        }
        
    }
    
    public static userBean getUser(String username)
    {
        String pw=null;
        String un=null;
        String rl=null;
               
        try{
            PreparedStatement getItemstmt=con.prepareStatement("select Username,Password,Role from Users where Username=?");
            getItemstmt.setString(1, username);
            ResultSet rs =getItemstmt.executeQuery();
            
            while(rs.next())
            {
                un=rs.getString("Username");
                pw=rs.getString("Password");
                rl=rs.getString("Role");
            }
        }
        
        catch(Exception e){}
        
        userBean user1=new userBean(un,pw,rl);
        
        return user1;
    }

    
     public static List<Model.Project> getProject()
    {
        String id=null;
        String title=null;
        String description=null;
        String studentsFeedback=null;
        String teachersFeedback=null;
        String teacher=null;
        String student=null;
        String startDate=null;
        String endDate=null;
        
        List <Model.Project> projectList = new ArrayList<Model.Project>();
        Project project1;
               
        try{
            PreparedStatement getItemstmt=con.prepareStatement("select * from Project");
            ResultSet rs =getItemstmt.executeQuery();
            
            while(rs.next())
            {
                id=rs.getString("ID");
                title=rs.getString("title");
                description=rs.getString("description");
                teacher=rs.getString("teacher");
                student=rs.getString("student");
                studentsFeedback=rs.getString("studentsFeedback");
                teachersFeedback=rs.getString("teachersFeedback");
                startDate=rs.getString("startDate");
                endDate=rs.getString("endDate");
             
                
                project1=new Project(id,title,description,teacher,student,studentsFeedback,teachersFeedback,startDate,endDate);
                projectList.add(project1);
            }
        }
        
        catch(Exception e){}

        return projectList;
}
     
  /*    public static item getItemToCart(String itemCode)
    {
        String ic=null;
        String in=null;
        String up=null;
        
        //List <item> itemList = new ArrayList<item>();
        item item1=null;
               
        try{
            PreparedStatement getItemstmt=con.prepareStatement("select itemCode,itemName,unitPrice from Item where itemCode=?");
            getItemstmt.setString(1, itemCode);
            ResultSet rs =getItemstmt.executeQuery();
            
            while(rs.next())
            {
                ic=rs.getString("itemCode");
                in=rs.getString("itemName");
                up=rs.getString("unitPrice");
                
                item1=new item(ic,in,up);
                //itemList.add(item1);
            }
        }
        
        catch(Exception e){}

        return item1;
    }
     
     
     */
    

    public static void setProject(Model.Project p)
    {
        try{
            PreparedStatement setProjectstmt=con.prepareStatement("Insert into Project(ID,title,description,teacher,student,studentsFeedback,teachersFeedback,startDate,endDate) Values(?,?,?,?,?,?,?,?,?)");
           setProjectstmt.setString(1,p.getID());
            setProjectstmt.setString(2,p.getTitle());
            setProjectstmt.setString(3,p.getDescription());
            setProjectstmt.setString(4,p.getTeacher());
            setProjectstmt.setString(5,p.getStudent());
            setProjectstmt.setString(6,p.getStudentsFeedback());
            setProjectstmt.setString(7,p.getTeachersFeedback());
            setProjectstmt.setString(8,p.getStartDate());
            setProjectstmt.setString(9,p.getEndDate());
            setProjectstmt.executeUpdate();
            //con.close();
        }
        
        catch(Exception es){
        
        }
    }
    
  /*  public static void setBoughtItem(boughtItemData data)
    {
        try{
            PreparedStatement setItemstmt=con.prepareStatement("Insert into BoughtItems(Username,ItemCode,Quantity) Values(?,?,?)");
            setItemstmt.setString(1,data.getUsername());
            setItemstmt.setString(2,data.getItemCode());
            setItemstmt.setInt(3,data.getQuantity());
            setItemstmt.executeUpdate();
            //con.close();
        }
        
        catch(Exception es){}
    }
    
    
     public static List<boughtItemData> getBoughtItem(String username)
    {
        String un=null;
        String ic=null;
        int qn=0;
        
        List <boughtItemData> itemList = new ArrayList<boughtItemData>();
        boughtItemData item1;
               
        try{
            PreparedStatement getItemstmt=con.prepareStatement("select * from BoughtItems where Username=?");
            getItemstmt.setString(1, username);
            ResultSet rs =getItemstmt.executeQuery();
            
            while(rs.next())
            {
                un=rs.getString("Username");
                ic=rs.getString("ItemCode");
                qn=Integer.parseInt(rs.getString("Quantity")) ;
                
                item1=new boughtItemData(un,ic,qn);
                itemList.add(item1);
            }
        }
        
        catch(Exception e){}

        return itemList;
    }
    
   
}

*/
}